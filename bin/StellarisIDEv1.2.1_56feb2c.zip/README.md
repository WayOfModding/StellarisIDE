[![Build Status](https://travis-ci.org/WayOfModding/StellarisIDE.svg?branch=dev)](https://travis-ci.org/WayOfModding/StellarisIDE)

StellarisIDE is an open-source software licensed under GPLv3.
It is aimed to help people create non-commercial mods for
Stellaris (R), which is a game developed by Paradox Interactive.

The project is published here:
https://github.com/WayOfModding/StellarisIDE

# TODO

- [ ] Add support for javax.script
- [ ] Add support for semantic analysis